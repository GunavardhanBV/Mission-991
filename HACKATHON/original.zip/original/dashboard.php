<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "mission991");

// Add new event
if (isset($_POST['add_event'])) {
    $name = $_POST['event_name'];
    $rules = $_POST['rules'];
    $timeline = $_POST['timeline'];
    $prizes = $_POST['prizes'];
    $sponsors = $_POST['sponsors'];
    $mode = $_POST['mode'];

    $conn->query("INSERT INTO events (event_name,rules,timeline,prizes,sponsors,mode) 
                  VALUES ('$name','$rules','$timeline','$prizes','$sponsors','$mode')");
}

// Delete event
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM events WHERE id=$id");
}

$events = $conn->query("SELECT * FROM events");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Dashboard</title>
  <style>
    table { border-collapse: collapse; width: 100%; }
    table, th, td { border: 1px solid black; padding: 8px; }
    .form-box { margin-bottom: 20px; }
  </style>
</head>
<body>
  <h2>Welcome Admin</h2>
  <a href="logout.php">Logout</a>

  <div class="form-box">
    <h3>Add New Event</h3>
    <form method="post">
      <input type="text" name="event_name" placeholder="Event Name" required><br>
      <textarea name="rules" placeholder="Rules"></textarea><br>
      <textarea name="timeline" placeholder="Timeline"></textarea><br>
      <input type="text" name="prizes" placeholder="Prizes"><br>
      <input type="text" name="sponsors" placeholder="Sponsors"><br>
      <select name="mode">
        <option value="Online">Online</option>
        <option value="Offline">Offline</option>
      </select><br>
      <button type="submit" name="add_event">Add Event</button>
    </form>
  </div>

  <h3>All Events</h3>
  <table>
    <td>
        <a href="edit.php?id=<?= $row['id'] ?>">Edit</a> | 
        <a href="?delete=<?= $row['id'] ?>">Delete</a>
    </td>

    <tr>
      <th>ID</th><th>Name</th><th>Rules</th><th>Timeline</th><th>Prizes</th><th>Sponsors</th><th>Mode</th><th>Action</th>
    </tr>
    <?php while($row = $events->fetch_assoc()): ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= $row['event_name'] ?></td>
      <td><?= $row['rules'] ?></td>
      <td><?= $row['timeline'] ?></td>
      <td><?= $row['prizes'] ?></td>
      <td><?= $row['sponsors'] ?></td>
      <td><?= $row['mode'] ?></td>
      <td><a href="?delete=<?= $row['id'] ?>">Delete</a></td>
    </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>
