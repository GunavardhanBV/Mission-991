<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "mission991");

// event fetch
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM events WHERE id=$id");
    $event = $result->fetch_assoc();
}

// update event
if (isset($_POST['update_event'])) {
    $name = $_POST['event_name'];
    $rules = $_POST['rules'];
    $timeline = $_POST['timeline'];
    $prizes = $_POST['prizes'];
    $sponsors = $_POST['sponsors'];
    $mode = $_POST['mode'];

    $conn->query("UPDATE events SET 
                    event_name='$name',
                    rules='$rules',
                    timeline='$timeline',
                    prizes='$prizes',
                    sponsors='$sponsors',
                    mode='$mode'
                  WHERE id=$id");

    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Event</title>
</head>
<body>
  <h2>Edit Event</h2>
  <form method="post">
    <input type="text" name="event_name" value="<?= $event['event_name'] ?>" required><br>
    <textarea name="rules"><?= $event['rules'] ?></textarea><br>
    <textarea name="timeline"><?= $event['timeline'] ?></textarea><br>
    <input type="text" name="prizes" value="<?= $event['prizes'] ?>"><br>
    <input type="text" name="sponsors" value="<?= $event['sponsors'] ?>"><br>
    <select name="mode">
      <option value="Online" <?= ($event['mode']=="Online")?"selected":"" ?>>Online</option>
      <option value="Offline" <?= ($event['mode']=="Offline")?"selected":"" ?>>Offline</option>
    </select><br>
    <button type="submit" name="update_event">Update Event</button>
  </form>
  <br>
  <a href="dashboard.php">Back to Dashboard</a>
</body>
</html>
