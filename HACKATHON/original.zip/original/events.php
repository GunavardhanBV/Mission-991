<?php
$conn = new mysqli("localhost", "root", "", "mission991");
$events = $conn->query("SELECT * FROM events");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Events</title>
</head>
<body>
  <h2>All Events</h2>
  <?php while($row = $events->fetch_assoc()): ?>
    <div style="border:1px solid #ccc; padding:10px; margin:10px;">
      <h3><?= $row['event_name'] ?></h3>
      <p><strong>Rules:</strong> <?= $row['rules'] ?></p>
      <p><strong>Timeline:</strong> <?= $row['timeline'] ?></p>
      <p><strong>Prizes:</strong> <?= $row['prizes'] ?></p>
      <p><strong>Sponsors:</strong> <?= $row['sponsors'] ?></p>
      <p><strong>Mode:</strong> <?= $row['mode'] ?></p>
    </div>
  <?php endwhile; ?>
</body>
</html>
